#!/usr/bin/env python3
"""Place official Android ARM64 Stockfish binary into jniLibs as libstockfish.so.
Usage: python scripts/install_stockfish.py /path/to/stockfish-android-armv8.zip
The archive must be downloaded from https://stockfishchess.org/download/ .
No downloads occur in this script.
"""
from pathlib import Path
import sys, zipfile, shutil
if len(sys.argv) != 2:
    raise SystemExit('Usage: python scripts/install_stockfish.py /path/to/stockfish-android-armv8.zip')
source=Path(sys.argv[1])
out=Path(__file__).resolve().parents[1] / 'app/src/main/jniLibs/arm64-v8a/libstockfish.so'
if source.suffix.lower()=='.zip':
    with zipfile.ZipFile(source) as z:
        candidates=[x for x in z.namelist() if Path(x).name.startswith('stockfish-android') or Path(x).name=='stockfish']
        if not candidates: raise SystemExit('Could not find Stockfish executable in archive: ' + str(z.namelist()))
        with z.open(candidates[0]) as src, open(out,'wb') as dst: shutil.copyfileobj(src,dst)
else: shutil.copyfile(source,out)
print('Installed:',out,'bytes:',out.stat().st_size)
print('IMPORTANT: use an official generic ARM64 Android binary, and verify it is a PIE executable.')
