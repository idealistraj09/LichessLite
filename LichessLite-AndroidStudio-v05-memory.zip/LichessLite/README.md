# LichessLite v0.5 — reduced-memory live capture (prototype)

Native Kotlin. Android 12 compatible in principle. No screenshot import flow and no manual top-ratio field.

## User flow

1. Grant overlay permission. Open Lichess **Analysis Board** (not a rated game).
2. Reset Lichess Analysis Board to the standard starting position. Make sure **all 32 pieces** are visible.
3. Tap floating knight > **Calibrate starting position** > grant Android **Start now** screen recording permission. The consent activity finishes automatically. Keep the board visible. The capture begins after a short redraw delay.
4. Tap floating knight > **Analyze current position** > approve capture. The board is found automatically by scanning for the chessboard checker pattern, not by a fixed top coordinate.
5. Review the editable FEN carefully and confirm side to move, castling rights and en passant, then run Stockfish.

The board theme/piece set/orientation must remain the same between calibration and analysis. Template matching is not flawless; Android screen capture always requires user consent on supported OS versions, and Realme may require extra overlay permission.

## Build with the existing GitHub Actions workflow

- Upload **LichessLite-AndroidStudio.zip** to repo root, replacing the old ZIP.
- Keep `.github/workflows/build-apk.yml` from the previously working Stockfish 19 direct-download workflow, using `Locate Android Gradle project`.
- Trigger workflow. It builds APK with Gradle 8.9, Android SDK 35, JDK 17, and bundles official Stockfish ARM64.

## Notes

The board locator scores alternating light/dark square colors and rejects screens with no checkerboard. Starting calibration verifies the occupancy pattern of initial chess positions. It was calibrated against the screenshot provided (376×750; true board near y=218) and finds near y=216 in an offline geometry test. On-device screen-capture return flow and recognizer accuracy still need testing. This environment has no Android SDK or Gradle installation, so no local APK was compiled here. Build via GitHub Actions.

## v0.5 device-log finding
On Realme Android 12, the previous app process was killed by Android lowmemorykiller during a one-shot 1080x2400 screen capture (15:54:19). This version captures at no more than 720 pixels wide, lowering peak ImageReader/bitmap memory about 56% for 1080-wide screens, and logs CAPTURE_START / CAPTURE_SAVED / CAPTURE_FAILED with tag LichessLite. The OS may still kill an app when system memory is exhausted. Actual board recognition and successful Stockfish output require a device regression test.
