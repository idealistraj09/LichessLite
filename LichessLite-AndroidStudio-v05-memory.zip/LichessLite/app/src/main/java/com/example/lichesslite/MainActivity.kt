package com.example.lichesslite

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.widget.EditText
import android.widget.ImageView
import java.io.File
import kotlin.concurrent.thread
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Explicit permission diagnostics for Realme / Android 12. Does not bypass AppOps. */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private val pickImageCode = 930
    private var importMode = "calibrate"
    private val recognizer by lazy { BoardRecognizer(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(30), dp(20), dp(24))
        }
        layout.addView(TextView(this).apply {
            text = "Lichess Lite - offline practice only\n\n" +
                "This app needs permission to display the floating chess icon. " +
                "Realme may restrict this permission."
            textSize = 16f
        })
        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(18), 0, dp(18))
        }
        layout.addView(status)
        addButton(layout, "1. Open overlay permission settings") {
            openSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        }
        addButton(layout, "2. Open Lichess Lite app info") {
            openSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")))
        }
        addButton(layout, "3. Check permission and enable floating icon") {
            refreshStatus()
            if (Settings.canDrawOverlays(this)) {
                try {
                    startService(Intent(this, FloatingService::class.java))
                    Toast.makeText(this, "Floating icon started", Toast.LENGTH_SHORT).show()
                    moveTaskToBack(true)
                } catch (e: Exception) {
                    status.text = status.text.toString() +
                        "\nCould not start overlay: ${e.javaClass.simpleName}: ${e.message}"
                }
            } else {
                Toast.makeText(this,
                    "Overlay is blocked. Check the status below and Realme permissions.",
                    Toast.LENGTH_LONG).show()
            }
        }
        addButton(layout, "Reset calibration (if board was wrong)") {
            recognizer.clearCalibration()
            Toast.makeText(this, "Calibration cleared", Toast.LENGTH_SHORT).show()
        }
        addButton(layout, "Refresh permission status") { refreshStatus() }
        addButton(layout, "Stop floating icon") {
            stopService(Intent(this, FloatingService::class.java))
        }
        layout.addView(TextView(this).apply {
            text = "If this app is missing from Settings > Display over other apps, " +
                "the phone may be restricting eligibility for overlays. " +
                "The app cannot grant this permission itself.\n\n" +
                "No root, hidden settings or bypass is required or attempted."
            textSize = 13f
            setPadding(0, dp(16), 0, 0)
        })
        setContentView(layout)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun refreshStatus() {
        val allowed = Settings.canDrawOverlays(this)
        val appOps = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val opMode = try {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                applicationInfo.uid,
                packageName
            )
        } catch (_: Exception) { -1 }
        val modeName = when (opMode) {
            AppOpsManager.MODE_ALLOWED -> "allow"
            AppOpsManager.MODE_IGNORED -> "ignore"
            AppOpsManager.MODE_ERRORED -> "deny"
            AppOpsManager.MODE_DEFAULT -> "default"
            else -> "unknown ($opMode)"
        }
        status.text = "Permission: ${if (allowed) "ALLOWED" else "BLOCKED"}\n" +
            "AppOps: $modeName\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Package: $packageName"
    }

    private fun openSettings(intent: Intent) {
        try { startActivity(intent) }
        catch (e: Exception) {
            Toast.makeText(this, "Unable to open Settings: ${e.message}",
                Toast.LENGTH_LONG).show()
        }
    }

    private fun addButton(layout: LinearLayout, label: String, action: () -> Unit) {
        layout.addView(Button(this).apply {
            text = label
            isAllCaps = false
            gravity = Gravity.CENTER
            setOnClickListener { action() }
        })
    }


    private fun pickScreenshot(mode: String) {
        importMode = mode
        val select = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(select, pickImageCode)
    }

    @Deprecated("Platform result API keeps the project dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickImageCode || resultCode != RESULT_OK || data?.data == null) return
        try {
            contentResolver.openInputStream(data.data!!)?.use { source ->
                File(cacheDir, "capture.png").outputStream().use { destination ->
                    source.copyTo(destination)
                }
            } ?: error("Unable to open the selected screenshot")
            if (importMode == "calibrate") verifyCalibrationImage()
            else analyzeImportedImage()
        } catch (e: Exception) {
            alert("Screenshot import failed", e.message ?: "Unknown error")
        }
    }

    private fun verifyCalibrationImage() {
        val bitmap = BitmapFactory.decodeFile(File(cacheDir, "capture.png").absolutePath)
            ?: run { alert("Invalid image", "Could not decode the image"); return }
        val preview = ImageView(this).apply {
            setImageBitmap(bitmap)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        AlertDialog.Builder(this)
            .setTitle("Verify starting position")
            .setMessage("Only continue if the screenshot shows the FULL standard starting chess position, with all 32 pieces. The board must be in the expected location. This prevents saving a home-screen image as calibration.")
            .setView(preview)
            .setPositiveButton("Yes, calibrate") { _, _ ->
                thread {
                    val result = runCatching { recognizer.calibrate() }
                    runOnUiThread {
                        result.fold(
                            onSuccess = { alert("Calibration saved", "Now capture the position you want to study using your phone's screenshot buttons, then choose Import position screenshot.") },
                            onFailure = { alert("Calibration failed", it.message ?: "Unknown error") }
                        )
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .setOnDismissListener { bitmap.recycle() }
            .show()
    }

    private fun analyzeImportedImage() {
        thread {
            val result = runCatching { recognizer.recognize(true) }
            runOnUiThread {
                result.fold(
                    onSuccess = { showFenReview(it) },
                    onFailure = { alert("Recognition failed", it.message ?: "Unknown error") }
                )
            }
        }
    }

    private fun showFenReview(result: BoardRecognizer.Result) {
        val fenInput = EditText(this).apply {
            setText(result.fen)
            setSingleLine(false)
            textSize = 14f
        }
        AlertDialog.Builder(this)
            .setTitle("Confirm position (FEN)")
            .setMessage("Review the detected pieces carefully. Screenshot recognition may be incorrect. Confirm the side to move, castling and en passant. Uncertain: ${result.uncertain.take(12).joinToString()}.")
            .setView(fenInput)
            .setPositiveButton("Analyze") { _, _ ->
                val fen = fenInput.text.toString().trim()
                val error = Fen.validate(fen)
                if (error != null) {
                    alert("Invalid FEN", "$error\n\nRecheck the screenshot, board orientation, and calibration.")
                } else {
                    thread {
                        val analysis = runCatching { Stockfish.analyze(this, fen) }
                        runOnUiThread {
                            analysis.fold(
                                onSuccess = { alert("Stockfish", "Best move: ${it.move}\n${it.eval}") },
                                onFailure = { alert("Stockfish error", it.message ?: "Unknown error") }
                            )
                        }
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun alert(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
