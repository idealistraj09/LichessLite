package com.example.lichesslite

import android.content.Context
import java.io.BufferedReader
import java.io.File
import java.util.concurrent.TimeUnit

/** Official ARM64 binary must be packaged as jniLibs/arm64-v8a/libstockfish.so. */
object Stockfish {
    data class Analysis(val move: String, val eval: String)
    fun analyze(ctx: Context, fen: String): Analysis {
        val err=Fen.validate(fen)
        require(err==null) { err ?: "Bad FEN" }
        val engine=File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        require(engine.exists()) { "Stockfish binary missing. Follow README setup steps." }
        val process=ProcessBuilder(engine.absolutePath).redirectErrorStream(true).start()
        val input=process.outputStream.bufferedWriter()
        val output=process.inputStream.bufferedReader()
        fun command(s: String) { input.write(s); input.newLine(); input.flush() }
        fun until(s: String) { while (true) { val line=output.readLine() ?: error("Stockfish exited"); if (line.startsWith(s)) return } }
        try {
            command("uci"); until("uciok")
            command("setoption name Threads value 1")
            command("setoption name Hash value 8")
            command("isready"); until("readyok")
            command("position fen $fen")
            command("go depth 11")
            var eval="Evaluation unavailable"
            var best="(none)"
            while (true) {
                val line=output.readLine() ?: error("Stockfish stopped")
                if (line.startsWith("info ")) {
                    val cp=Regex("\\bscore cp (-?\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()
                    val mate=Regex("\\bscore mate (-?\\d+)").find(line)?.groupValues?.get(1)
                    if (mate!=null) eval="Mate in $mate (side to move)"
                    else if (cp!=null) eval="${"%+.2f".format(java.util.Locale.US,cp/100.0)} (side to move)"
                }
                if (line.startsWith("bestmove ")) { best=line.split(' ').getOrNull(1) ?: "(none)"; break }
            }
            return Analysis(best,eval)
        } finally {
            runCatching { command("quit") }
            if (!process.waitFor(700,TimeUnit.MILLISECONDS)) process.destroyForcibly()
            runCatching { input.close(); output.close() }
        }
    }
}
