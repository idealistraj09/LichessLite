package com.example.lichesslite

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.min

/** Searches for a chessboard's alternating square colors; independent of screen height. */
object BoardLocator {
    data class Detection(val rect: Rect, val contrast: Double, val score: Double)

    fun locate(image: Bitmap): Detection {
        val w = image.width
        val h = image.height
        require(w >= 160 && h >= 160) { "Screenshot too small to find a chessboard" }
        val maxSide = min(w, h)
        var best: Detection? = null
        // Lichess on portrait phones generally uses 80-100% of the available width.
        for (fraction in listOf(1.0, 0.96, 0.90, 0.84, 0.78)) {
            val side = (maxSide * fraction).toInt().let { it - it % 8 }
            val xPositions = listOf(0, (w-side)/2, w-side).distinct().filter { it >= 0 }
            val step = (side / 80).coerceAtLeast(2)
            for (left in xPositions) for (top in 0..(h-side) step step) {
                val d = evaluate(image, left, top, side)
                if (best == null || d.score > best!!.score) best = d
            }
        }
        val found = best ?: error("Could not find a board")
        require(found.contrast >= 19.0 && found.score > 9.0) {
            "No clear 8x8 chessboard detected (contrast=${"%.1f".format(java.util.Locale.US,found.contrast)}). Return to the Lichess analysis board and retry."
        }
        return found
    }

    // Use near-corner samples to avoid the chess pieces in the centers of squares.
    private fun evaluate(b: Bitmap, left: Int, top: Int, size: Int): Detection {
        val means = DoubleArray(2)
        val counts = IntArray(2)
        val values = DoubleArray(64)
        for (r in 0..7) for (c in 0..7) {
            val x = (left + (c + 0.12) * size / 8).toInt().coerceIn(0,b.width-1)
            val y = (top + (r + 0.12) * size / 8).toInt().coerceIn(0,b.height-1)
            val p = b.getPixel(x,y)
            val lum = .2126*Color.red(p) + .7152*Color.green(p) + .0722*Color.blue(p)
            values[r*8+c] = lum
            val parity = (r+c)%2
            means[parity]+=lum
            counts[parity]++
        }
        means[0]/=counts[0]; means[1]/=counts[1]
        val contrast = abs(means[0]-means[1])
        var deviation=0.0
        for (r in 0..7) for (c in 0..7) deviation += abs(values[r*8+c]-means[(r+c)%2])
        deviation /=64.0
        // Prefer a coherent checkerboard over unrelated high-contrast areas.
        val score = contrast - 0.55*deviation
        return Detection(Rect(left,top,left+size,top+size),contrast,score)
    }
}
