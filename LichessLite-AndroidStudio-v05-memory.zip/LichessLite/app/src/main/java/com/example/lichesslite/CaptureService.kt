package com.example.lichesslite

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Log
import android.view.WindowManager
import java.io.File

class CaptureService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var mp: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var complete = false
    private var mode = "analyze"
    private val callback = object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("capture", "Screen capture", NotificationManager.IMPORTANCE_LOW))
        val note = Notification.Builder(this, "capture")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Lichess Lite").setContentText("Capturing one chess board frame").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(31, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(31, note)
        val code = intent?.getIntExtra("code", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION") val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra<Intent>("data")
        mode = intent?.getStringExtra("mode") ?: "analyze"
        if (code != Activity.RESULT_OK || data == null) { report("Screen capture permission not granted"); return START_NOT_STICKY }
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mp = mpm.getMediaProjection(code, data)
            mp!!.registerCallback(callback, main)
            // For this lightweight version a full-display capture is required.
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds else {
                @Suppress("DEPRECATION") val dm = resources.displayMetrics
                android.graphics.Rect(0,0,dm.widthPixels,dm.heightPixels)
            }
            // Capture at a reduced resolution to avoid retaining multiple 1080x2400
            // bitmaps alongside Lichess on memory-constrained Realme devices.
            // Keep aspect ratio and make dimensions safe for the ImageReader.
            val sourceWidth = metrics.width()
            val sourceHeight = metrics.height()
            val width = minOf(sourceWidth, 720)
            val height = (sourceHeight.toLong() * width / sourceWidth).toInt().coerceAtLeast(1)
            Log.i("LichessLite", "CAPTURE_START source=${sourceWidth}x${sourceHeight} output=${width}x${height}")
            val density = resources.displayMetrics.densityDpi
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader!!.setOnImageAvailableListener({ src ->
                if (complete) { src.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
                val image = src.acquireLatestImage() ?: return@setOnImageAvailableListener
                complete = true
                try {
                    val plane = image.planes[0]
                    val paddedWidth = plane.rowStride / plane.pixelStride
                    val bitmap = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
                    bitmap.copyPixelsFromBuffer(plane.buffer)
                    val exact = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                    val path = File(cacheDir, "capture.png")
                    path.outputStream().use { exact.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    exact.recycle(); bitmap.recycle()
                    Log.i("LichessLite", "CAPTURE_SAVED ${width}x${height}, bytes=${path.length()}")
                    report(null)
                } catch (t: Throwable) {
                    Log.e("LichessLite", "CAPTURE_FAILED", t)
                    report(t.message ?: "Capture failed")
                } finally { image.close(); stopSelf() }
            }, main)
            // Permission UI may have temporarily obscured the target. Allow its
            // translucent activity to close and the chessboard to redraw.
            main.postDelayed({
                if (!complete && mp != null) {
                    try {
                        display = mp!!.createVirtualDisplay("LichessOneShot", width, height, density,
                            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, main)
                    } catch (e: Exception) {
                        complete = true
                        report("Unable to start screen capture: ${e.message}")
                        stopSelf()
                    }
                }
            }, 1400)
            main.postDelayed({ if (!complete) { complete=true; report("Capture timed out. Keep the Lichess board visible after pressing Start now."); stopSelf() } }, 7000)
        } catch (e: Exception) { Log.e("LichessLite", "Capture failure", e); report(e.message ?: "Capture failure"); stopSelf() }
        return START_NOT_STICKY
    }
    private fun report(error: String?) {
        if (error != null) Log.w("LichessLite", "CAPTURE_RESULT: $error")
        startService(Intent(this, FloatingService::class.java).apply {
            action = "CAPTURE_RESULT"; putExtra("error", error); putExtra("mode", mode)
        })
    }
    override fun onDestroy() {
        reader?.setOnImageAvailableListener(null, null)
        display?.release()
        try { mp?.unregisterCallback(callback) } catch (_: Exception) {}
        mp?.stop(); reader?.close()
        super.onDestroy()
    }
}
