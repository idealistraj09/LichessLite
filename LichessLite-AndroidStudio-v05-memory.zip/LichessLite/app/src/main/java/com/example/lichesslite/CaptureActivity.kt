package com.example.lichesslite

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

/** Translucent one-time consent screen; finishes immediately to expose Lichess again. */
class CaptureActivity : Activity() {
    private val requestCode = 901
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
        }
    }
    @Deprecated("Platform Activity result API keeps the project dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK && data != null) {
            val start = Intent(this, CaptureService::class.java).apply {
                putExtra("code", resultCode)
                putExtra("data", data)
                putExtra("mode", intent.getStringExtra("mode") ?: "analyze")
            }
            startForegroundService(start)
        } else {
            startService(Intent(this, FloatingService::class.java).apply {
                action="CAPTURE_RESULT"
                putExtra("error", "Capture permission was cancelled")
            })
        }
        // Do not bring LichessLite's main activity or Lichess home to the foreground.
        finish()
    }
}
