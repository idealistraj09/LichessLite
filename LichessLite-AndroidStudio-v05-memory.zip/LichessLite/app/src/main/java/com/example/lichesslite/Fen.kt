package com.example.lichesslite

object Fen {
    fun validate(fen: String): String? {
        val parts=fen.trim().split(Regex("\\s+"))
        if (parts.size!=6) return "FEN must contain 6 fields (board turn castling en-passant halfmove fullmove)"
        val rows=parts[0].split('/')
        if (rows.size!=8) return "FEN needs eight ranks"
        val pieces=mutableListOf<Char>()
        for (row in rows) {
            var n=0
            for (c in row) {
                if (c in '1'..'8') n+=c.digitToInt()
                else if (c in "KQRBNPkqrbnp") { n++; pieces.add(c) }
                else return "Invalid FEN piece: $c"
            }
            if (n!=8) return "Every FEN rank must contain eight squares"
        }
        if (pieces.count { it=='K' } != 1 || pieces.count { it=='k' } != 1) return "Exactly one king of each color required"
        if (pieces.count { it=='P' } > 8 || pieces.count { it=='p' } > 8) return "Too many pawns"
        if (rows.first().any { it in "Pp" } || rows.last().any { it in "Pp" }) return "Pawn on first or last rank"
        if (parts[1] !in setOf("w","b")) return "Side to move must be w or b"
        if (parts[2]!="-" && (!parts[2].all { it in "KQkq" } || parts[2].toSet().size!=parts[2].length)) return "Invalid castling rights"
        if (!Regex("-|[a-h][36]").matches(parts[3])) return "Invalid en-passant square"
        if (parts[4].toIntOrNull()?.let { it>=0 } != true || parts[5].toIntOrNull()?.let { it>=1 } != true) return "Invalid move counters"
        // This checks syntax/basic consistency only; not full position legality.
        return null
    }
}
