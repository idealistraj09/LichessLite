package com.example.lichesslite

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/** Fixed-theme, one-time calibration recognition, no ML dependencies. */
class BoardRecognizer(private val context: Context) {
    private val prefs = context.getSharedPreferences("calibration", Context.MODE_PRIVATE)
    private val side = 24
    private val backgroundThreshold = 49
    private val start = arrayOf(
        "rnbqkbnr", "pppppppp", "........", "........",
        "........", "........", "PPPPPPPP", "RNBQKBNR"
    )
    data class Result(val fen: String, val uncertain: List<String>, val board: String)

    fun settings(blackBottom: Boolean, topRatio: Float) {
        prefs.edit().putBoolean("black", blackBottom).putFloat("top", topRatio).apply()
    }
    fun blackBottom(): Boolean = prefs.getBoolean("black", true)
    fun topRatio(): Float = prefs.getFloat("top", 0.292f)
    fun calibrated(): Boolean = prefs.contains("templates")
    fun clearCalibration() { prefs.edit().remove("templates").apply() }
    private fun capture(): Bitmap = BitmapFactory.decodeFile(File(context.cacheDir, "capture.png").absolutePath)
        ?: error("No screenshot saved")

    private fun boardRect(bitmap: Bitmap): android.graphics.Rect {
        // Screenshot supplied: 376x750; board x=0..376, y=219..595.
        // Only supports a similarly full-width, square board at the configured top ratio.
        val size = min(bitmap.width, bitmap.height)
        val top = (bitmap.height * topRatio()).toInt()
        val left = (bitmap.width - size) / 2
        require(top >= 0 && top + size <= bitmap.height) { "Board crop outside image; adjust Top ratio" }
        return android.graphics.Rect(left, top, left+size, top+size)
    }
    private fun pieceAt(row: Int, col: Int, black: Boolean): Char =
        if (black) start[7-row][7-col] else start[row][col]

    // Feature extraction relative to local square background: insensitive to
    // normal brown/beige vs green last-move highlight. Includes piece color.
    private fun vector(image: Bitmap, row: Int, col: Int, rect: android.graphics.Rect): DoubleArray {
        val x0 = rect.left + col * rect.width() / 8
        val y0 = rect.top + row * rect.height() / 8
        val x1 = rect.left + (col+1) * rect.width() / 8
        val y1 = rect.top + (row+1) * rect.height() / 8
        val w=x1-x0; val h=y1-y0
        fun pixel(rx: Double, ry: Double): Int = image.getPixel(
            (x0+rx*w).toInt().coerceIn(x0,x1-1), (y0+ry*h).toInt().coerceIn(y0,y1-1))
        val bg = pixel(0.07, 0.07)
        val br=Color.red(bg); val bgG=Color.green(bg); val bb=Color.blue(bg)
        val out = DoubleArray(side*side*2)
        for (y in 0 until side) for (x in 0 until side) {
            // Ignore coordinate labels and extreme outside corner samples.
            val px = pixel((x+0.5)/side, (y+0.5)/side)
            val r=Color.red(px);val g=Color.green(px);val b=Color.blue(px)
            val distance = abs(r-br)+abs(g-bgG)+abs(b-bb)
            val idx = (y*side+x)*2
            if (distance >= backgroundThreshold) {
                out[idx]=1.0
                out[idx+1]=(r+g+b)/765.0
            }
        }
        return out
    }
    private fun similarity(a: DoubleArray,b: DoubleArray): Double {
        var total=0.0
        for (i in a.indices) {
            val diff=a[i]-b[i]
            total+=diff*diff
        }
        return total/a.size
    }
    fun calibrate() {
        val bmp=capture()
        try {
            val rect=boardRect(bmp)
            val groups=linkedMapOf<Char,MutableList<DoubleArray>>()
            val black=blackBottom()
            for (row in 0..7) for (col in 0..7) {
                val piece=pieceAt(row,col,black)
                if (piece!='.') groups.getOrPut(piece) { mutableListOf() }.add(vector(bmp,row,col,rect))
            }
            val json=JSONObject()
            for ((piece,images) in groups) {
                // Save all samples, rather than average 2 rook images whose positions differ.
                val samples=JSONArray()
                for (v in images) {
                    val arr=JSONArray()
                    for (num in v) arr.put((num*255).toInt())
                    samples.put(arr)
                }
                json.put(piece.toString(), samples)
            }
            require(json.length()==12) { "Incomplete start position calibration" }
            prefs.edit().putString("templates",json.toString()).apply()
        } finally { bmp.recycle() }
    }
    fun recognize(whiteToMove: Boolean): Result {
        val json=JSONObject(prefs.getString("templates",null) ?: error("Calibrate on the initial position first"))
        val refs=linkedMapOf<Char,List<DoubleArray>>()
        for (piece in "KQRBNPkqrbnp") {
            val samples=json.getJSONArray(piece.toString())
            refs[piece]=(0 until samples.length()).map { i ->
                val a=samples.getJSONArray(i)
                DoubleArray(a.length()) { a.getInt(it)/255.0 }
            }
        }
        val bmp=capture()
        try {
            val rect=boardRect(bmp)
            val screen=Array(8) { CharArray(8) { '.' } }
            val uncertain= mutableListOf<String>()
            for (row in 0..7) for (col in 0..7) {
                val v=vector(bmp,row,col,rect)
                val occupied=v.indices.step(2).count { v[it] > 0.5 }.toDouble()/(side*side)
                val scores=refs.map { (piece,images) -> piece to images.minOf { similarity(v,it) } }.sortedBy { it.second }
                // Low occupancy => empty, but overlay highlights/coordinate labels
                // may still require manual confirmation.
                val label = if (occupied < 0.065) '.' else scores.first().first
                screen[row][col]=label
                val confidenceGap = if (scores.size > 1) scores[1].second - scores[0].second else 1.0
                if ((label!='.' && (scores[0].second>0.15 || confidenceGap<0.018)) || (label=='.' && occupied>0.035)) {
                    val file=if (blackBottom()) 'h'-col else 'a'+col
                    val rank=if (blackBottom()) row+1 else 8-row
                    uncertain.add("$file$rank")
                }
            }
            val canonical = Array(8) { CharArray(8) { '.' } }
            for (row in 0..7) for (col in 0..7) {
                val r=if (blackBottom()) 7-row else row
                val c=if (blackBottom()) 7-col else col
                canonical[r][c]=screen[row][col]
            }
            val rows=canonical.map { rank ->
                buildString {
                    var empty=0
                    for (c in rank) {
                        if (c=='.') empty++ else { if (empty>0) append(empty); empty=0; append(c) }
                    }
                    if (empty>0) append(empty)
                }
            }
            val board=rows.joinToString("/")
            return Result("$board ${if (whiteToMove) "w" else "b"} - - 0 1",uncertain,board)
        } finally { bmp.recycle() }
    }
}
