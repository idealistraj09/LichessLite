package com.example.lichesslite

import android.app.Service
import android.provider.Settings
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.*
import kotlin.concurrent.thread

/** Tiny WindowManager overlay; no WebView, Compose, or ML libraries. */
class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var icon: TextView? = null
    private var panel: LinearLayout? = null
    private val main=Handler(Looper.getMainLooper())
    private val recognizer by lazy { BoardRecognizer(this) }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val floating = TextView(this).apply {
            text="♞"; textSize=31f; gravity=Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(35,76,139))
            elevation=12f
            setOnClickListener { showMenu() }
            setOnLongClickListener { showMenu(); true }
        }
        icon=floating
        if (!Settings.canDrawOverlays(this)) {
            android.util.Log.w("LichessLite", "Overlay permission unavailable; stopping service")
            stopSelf()
            return
        }
        try {
            wm.addView(floating, WindowManager.LayoutParams(dp(52),dp(52),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.END; x=8; y=140
            })
        } catch (e: SecurityException) {
            android.util.Log.e("LichessLite", "Realme blocked overlay window", e)
            icon=null
            stopSelf()
        } catch (e: WindowManager.BadTokenException) {
            android.util.Log.e("LichessLite", "Overlay token rejected", e)
            icon=null
            stopSelf()
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action=="CAPTURE_RESULT") {
            icon?.visibility=View.VISIBLE
            val error=intent.getStringExtra("error")
            val mode=intent.getStringExtra("mode") ?: "analyze"
            if (error!=null) showMessage("Screen capture", error)
            else if (mode=="calibrate") {
                thread {
                    val response=runCatching { recognizer.calibrate(); "Calibration saved. Switch to an offline analysis position and tap Analyze." }
                        .getOrElse { "Calibration failed: ${it.message}" }
                    main.post { showMessage("Calibration",response) }
                }
            } else {
                thread {
                    val response=runCatching { recognizer.recognize(true) }
                    main.post { response.fold(
                        onSuccess={ showFenReview(it) },
                        onFailure={ showMessage("Recognition error",it.message ?: "Unknown problem") }
                    ) }
                }
            }
        }
        return START_STICKY
    }
    private fun dp(n:Int):Int=(n*resources.displayMetrics.density).toInt()
    private fun button(text:String, action:()->Unit): Button = Button(this).apply {
        this.text=text; isAllCaps=false; setOnClickListener { action() }
    }
    private fun edit(text:String):EditText = EditText(this).apply {
        setText(text); textSize=14f; setSingleLine(false)
    }
    private fun text(text:String):TextView = TextView(this).apply {
        this.text=text; textSize=15f; setTextColor(Color.BLACK)
    }
    private fun showPanel(title:String, content:(LinearLayout)->Unit) {
        closePanel()
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12))
            setBackgroundColor(Color.rgb(250,250,248)); elevation=16f
        }
        root.addView(text(title).apply { textSize=18f })
        val scroll=ScrollView(this)
        val body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll,LinearLayout.LayoutParams(-1,-2).apply { weight=1f })
        content(body)
        body.addView(button("Close") { closePanel() })
        val params=WindowManager.LayoutParams(dp(335),-2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            0,PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL; y=dp(75)
            softInputMode=WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        panel=root; wm.addView(root,params)
    }
    private fun showMenu() {
        showPanel("Lichess Lite — offline only") { body ->
            body.addView(text("Use the Lichess analysis board, not an ongoing rated game."))
            val orientation=CheckBox(this).apply { text="Black pieces at bottom"; isChecked=recognizer.blackBottom() }
            body.addView(orientation)
            body.addView(text("Board top as a fraction of screenshot height (your sample: 0.292):"))
            val ratio=edit(recognizer.topRatio().toString()); body.addView(ratio)
            fun save():Boolean {
                val v=ratio.text.toString().toFloatOrNull()
                if (v==null || v !in 0f..0.8f) { ratio.error="Enter ratio between 0 and 0.8"; return false }
                recognizer.settings(orientation.isChecked,v); return true
            }
            body.addView(button("1. Calibrate starting position") { if (save()) launchCapture("calibrate") })
            body.addView(button("2. Analyze current position") {
                if (save()) {
                    if (!recognizer.calibrated()) showMessage("Setup required","Calibrate on a standard starting position first.")
                    else launchCapture("analyze")
                }
            })
            body.addView(button("Stop floating icon") { stopSelf() })
        }
    }
    private fun launchCapture(mode:String) {
        closePanel(); icon?.visibility=View.GONE
        try {
            val capture=Intent(this,CaptureActivity::class.java).apply {
                flags=Intent.FLAG_ACTIVITY_NEW_TASK; putExtra("mode",mode)
            }
            startActivity(capture)
        } catch (t:Throwable) { icon?.visibility=View.VISIBLE; showMessage("Cannot capture",t.message ?: "Unable to open permission prompt") }
    }
    private fun showMessage(title:String,message:String) {
        showPanel(title) { body -> body.addView(text(message)) }
    }
    private fun showFenReview(result:BoardRecognizer.Result) {
        showPanel("Verify position before analysis") { body ->
            body.addView(text("Recognized FEN (editable). Check every piece, side to move, castling rights and en passant."))
            if (result.uncertain.isNotEmpty()) body.addView(text("Check these squares: ${result.uncertain.take(16).joinToString()}${if (result.uncertain.size>16) " ..." else ""}"))
            val fenInput=edit(result.fen)
            body.addView(fenInput)
            body.addView(text("FEN default is White to move, with no castling/en passant. Change these if needed."))
            body.addView(button("Analyze confirmed FEN") {
                val fen=fenInput.text.toString().trim()
                val error=Fen.validate(fen)
                if (error!=null) { fenInput.error=error; return@button }
                showMessage("Stockfish","Analyzing confirmed position...")
                thread {
                    val r=runCatching { Stockfish.analyze(this,fen) }
                    main.post {
                        r.fold(
                            onSuccess={ showMessage("Stockfish suggestion", "Best move (UCI): ${it.move}\n${it.eval}") },
                            onFailure={ showMessage("Stockfish error",it.message ?: "Engine error") }
                        )
                    }
                }
            })
        }
    }
    private fun closePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel=null
    }
    override fun onDestroy() {
        closePanel()
        icon?.let { runCatching { wm.removeView(it) } }
        icon=null
        super.onDestroy()
    }
}
