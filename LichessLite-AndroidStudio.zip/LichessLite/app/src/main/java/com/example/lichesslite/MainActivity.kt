package com.example.lichesslite

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        fun btn(label: String, onClick: () -> Unit) { layout.addView(Button(this).apply { text = label; setOnClickListener { onClick() } }) }
        layout.addView(TextView(this).apply { text = "Lichess Lite — offline analysis only\n\n1. Open a Lichess analysis board at the normal starting position.\n2. Long-press the ♞ icon and choose Calibrate.\n3. Later choose Analyze, verify FEN, then run Stockfish.\n\nSet Lichess to the same piece theme and zoom for both steps.\n\nThis app is not for rated or live competitive assistance."; textSize = 16f })
        btn("Enable floating icon") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else { startService(Intent(this, FloatingService::class.java)); Toast.makeText(this, "Floating ♞ enabled", Toast.LENGTH_SHORT).show(); moveTaskToBack(true) }
        }
        btn("Stop floating icon") { stopService(Intent(this, FloatingService::class.java)) }
        setContentView(layout)
    }
}
