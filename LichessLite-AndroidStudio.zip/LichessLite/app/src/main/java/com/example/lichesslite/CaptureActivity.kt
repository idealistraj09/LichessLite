package com.example.lichesslite

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

class CaptureActivity : Activity() {
    private val requestCode = 901
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
    }
    @Deprecated("Uses platform Activity result API to avoid dependencies")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK && data != null) {
            val mode = intent.getStringExtra("mode") ?: "analyze"
            val start = Intent(this, CaptureService::class.java).apply {
                putExtra("code", resultCode)
                putExtra("data", data)
                putExtra("mode", mode)
            }
            startForegroundService(start)
        }
        moveTaskToBack(true)
        finish()
    }
}
