# Lichess Lite — offline chess board analyzer (Android)

A small, Kotlin-only prototype for **permitted offline analysis and practice**. It has a single overlay ♞, one-shot Android screen capture, training-free piece recognition, an editable FEN confirmation popup, and Stockfish via UCI. It does not send screenshots to any server or use ML dependencies.

## Status / honest limitations

- **Source project, not a prebuilt or device-tested APK.** This environment does not contain the Android SDK/Gradle, so compiling it here was not possible.
- **You must add an official Stockfish Android ARM64 binary**; it is not bundled. The native binary and its NNUE model dominate package size. The 5–15 MB APK number is NOT guaranteed.
- Recognition is deliberately lightweight/heuristic. It **requires calibration from a standard initial Lichess position** using exactly the same theme, pieces, zoom and orientation; captures with highlighted squares, move arrows, changed board size, or alternate board themes may fail. **Always verify/edit the FEN**. No automatic reconstruction of castling rights, en passant or active turn.
- Crop defaults to the uploaded 376x750 screenshot's `top = 0.292 × image height`, square board filling the screen width. Adjust in the floating menu if your device differs.
- No attempt to bypass anti-cheat measures or protected screenshots. Do not use for competitive or rated games.
- This prototype targets Android 8+ and compiles with SDK 35, Kotlin 2.0.21, Android Gradle Plugin 8.7.3. Modern Android versions have additional projection/foreground service restrictions; test on your device.
- Current capture flow uses the Android system permission dialog on **every analysis screenshot**. Select the entire screen rather than a single app window for this calibration layout.
- Android may block an overlay service launching a capture-consent activity in the background on some versions. If so, open the app to initiate capture or adapt the flow to a notification action.

## Build

1. Open this folder in **Android Studio** (JDK 17, Android SDK 35 installed). Allow it to download the Gradle 8.9 / AGP dependencies. If Studio reports a missing wrapper, use the installed Gradle 8.9 or generate one via `gradle wrapper --gradle-version 8.9`.
2. Download an **Android ARM64 (armv8 generic)** binary archive from https://stockfishchess.org/download/ . Stockfish is GPLv3; review its license and comply when distributing a modified or packaged application.
3. Run `python scripts/install_stockfish.py /path/to/stockfish-android-armv8.zip` (or an unzipped executable). Packaging the ELF executable with a `.so` filename under `jniLibs/arm64-v8a` allows Android to extract it to nativeLibraryDir, which the app executes as a subprocess. This packaging strategy needs validation against the exact downloaded binary and OS.
4. Build -> Build APK(s), install the APK on an ARM64 Android phone. Enable **Display over other apps**.
5. Open **Lichess analysis board** at the normal starting position. Tap ♞ -> **Calibrate starting position**, and allow whole-screen capture. Return to the chess board before the capture starts.
6. Open a permitted offline position. Tap ♞ -> **Analyze current position**, consent to capture, confirm the recognized FEN, adjust side-to-move/castling/en-passant if necessary, then Analyze confirmed FEN.

## Technical layout

- `MainActivity.kt`: overlay permission and start/stop
- `FloatingService.kt`: overlay icon and compact panels
- `CaptureActivity.kt`: Android screen capture consent
- `CaptureService.kt`: one-shot MediaProjection foreground service
- `BoardRecognizer.kt`: 24x24 per-square pixel descriptors calibrated on standard starting position
- `Fen.kt`: basic FEN validation (not chess legality)
- `Stockfish.kt`: synchronous UCI wrapper; called from a worker thread
- `scripts/install_stockfish.py`: optional manual binary installer

## License and credits

This repository's example Kotlin code is supplied for learning and experimentation. Stockfish and Lichess have their own licenses. The project does **not** bundle or copy their chess piece assets or Stockfish binaries.
